# 🚗 AutoGerência — Sistema de Concessionária

Aplicação web completa em Node.js + MongoDB + EJS para gerenciamento de estoque de veículos.

## 📋 Requisitos

- Node.js (v18+)
- MongoDB rodando localmente na porta 27017

## 🚀 Instalação e Execução

```bash
# Instalar dependências
npm install

# Iniciar servidor (porta 80 — pode precisar de sudo no Linux/Mac)
sudo node index.js

# Ou altere a porta no index.js para 3000 em desenvolvimento
```

Acesse: **http://localhost** (ou http://localhost:3000 se alterou a porta)

## 📁 Estrutura do Projeto

```
concessionaria/
├── index.js               # Servidor principal (porta 80)
├── models/
│   ├── Usuario.js          # Coleção: Usuarios (nome, login, senha)
│   └── Carro.js            # Coleção: Carros (marca, modelo, ano, qtde_disponivel)
├── routes/
│   ├── auth.js             # Rotas: /login, /cadastro, /logout
│   └── carros.js           # Rotas: /carros (CRUD completo)
├── views/
│   ├── login.ejs           # Página de login
│   ├── cadastro.ejs        # Página de cadastro de usuário
│   ├── partials/           # Componentes reutilizáveis (header, footer, alerts)
│   └── carros/
│       ├── listagem.ejs    # Listagem pública dos carros (rota '/')
│       ├── gerencia.ejs    # Gerência com CRUD (protegida)
│       └── formulario.ejs  # Formulário cadastrar/editar carro
└── public/css/style.css    # Estilos da aplicação
```

## 🗄️ Banco de Dados (MongoDB)

### Coleção: `usuarios`
| Campo  | Tipo   | Descrição          |
|--------|--------|--------------------|
| nome   | String | Nome completo       |
| login  | String | Login único         |
| senha  | String | Senha (bcrypt hash) |

### Coleção: `carros`
| Campo            | Tipo   | Descrição            |
|------------------|--------|----------------------|
| marca            | String | Marca do veículo     |
| modelo           | String | Modelo do veículo    |
| ano              | Number | Ano de fabricação    |
| qtde_disponivel  | Number | Quantidade em estoque|

## 📄 Páginas

| Rota               | Página               | Acesso     |
|--------------------|----------------------|------------|
| `/`                | → redireciona carros | Público    |
| `/carros`          | Listagem estoque     | Público    |
| `/login`           | Login usuário        | Público    |
| `/cadastro`        | Cadastro usuário     | Público    |
| `/carros/gerencia` | Painel gerência      | 🔒 Login  |
| `/carros/novo`     | Cadastrar carro      | 🔒 Login  |
| `/carros/:id/editar` | Editar carro       | 🔒 Login  |

## ⚙️ Operações CRUD

| Operação | Rota                         | Método  |
|----------|------------------------------|---------|
| Create   | POST `/carros`               | Novo carro |
| Read     | GET `/carros`                | Listar carros |
| Update   | PUT `/carros/:id`            | Atualizar carro |
| Delete   | DELETE `/carros/:id`         | Remover carro |
| Vender   | POST `/carros/:id/vender`    | Decrementa qtde |

## 🎨 CSS

- Fundo escuro (`#0d0f14`) com gradientes sutis
- Elementos centralizados com Flexbox e CSS Grid
- Tipografia: Bebas Neue (títulos) + DM Sans (texto)
- Cores: vermelho accent, superfícies escuras, badges coloridos
- Cards, tabela responsiva, formulários estilizados
