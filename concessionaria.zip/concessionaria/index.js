const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const flash = require('connect-flash');
const methodOverride = require('method-override');
const path = require('path');

const app = express();

// MongoDB connection
mongoose.connect('mongodb+srv://p_duram:Mmjgpe21%40@fei.lk9qmlv.mongodb.net/?appName=FEI',)
.then(() => console.log('✅ MongoDB conectado'))
  .catch(err => console.log('❌ Erro MongoDB:', err));

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(methodOverride('_method'));
app.use(session({
  secret: 'concessionaria-secret-2024',
  resave: false,
  saveUninitialized: false
}));
app.use(flash());

// Global vars
app.use((req, res, next) => {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.usuario = req.session.usuario || null;
  next();
});

// Routes
const authRoutes = require('./routes/auth');
const carrosRoutes = require('./routes/carros');

app.use('/', authRoutes);
app.use('/carros', carrosRoutes);

// Default route -> listagem de carros
app.get('/', (req, res) => res.redirect('/carros'));

// PORT 80
const PORT = 80;
app.listen(PORT, () => {
  console.log(`🚗 Servidor rodando na porta ${PORT}`);
});
