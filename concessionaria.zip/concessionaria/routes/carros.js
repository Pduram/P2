const express = require('express');
const router = express.Router();
const Carro = require('../models/Carro');

// Middleware de autenticação
function autenticado(req, res, next) {
  if (req.session.usuario) return next();
  req.flash('error_msg', 'Faça login para acessar esta página.');
  res.redirect('/login');
}

// GET listagem pública de carros (READ)
router.get('/', async (req, res) => {
  try {
    const carros = await Carro.find().sort({ createdAt: -1 });
    res.render('carros/listagem', { carros });
  } catch (err) {
    req.flash('error_msg', 'Erro ao carregar carros.');
    res.redirect('/');
  }
});

// GET gerência (protegida)
router.get('/gerencia', autenticado, async (req, res) => {
  try {
    const carros = await Carro.find().sort({ marca: 1 });
    res.render('carros/gerencia', { carros });
  } catch (err) {
    req.flash('error_msg', 'Erro ao carregar gerência.');
    res.redirect('/carros');
  }
});

// GET formulário novo carro
router.get('/novo', autenticado, (req, res) => {
  res.render('carros/formulario', { carro: null, acao: 'Cadastrar', method: 'POST', action: '/carros' });
});

// POST cadastrar carro (CREATE)
router.post('/', autenticado, async (req, res) => {
  const { marca, modelo, ano, qtde_disponivel } = req.body;

  if (!marca || !modelo || !ano || qtde_disponivel === undefined) {
    req.flash('error_msg', 'Preencha todos os campos.');
    return res.redirect('/carros/novo');
  }

  try {
    const carro = new Carro({ marca, modelo, ano, qtde_disponivel });
    await carro.save();
    req.flash('success_msg', 'Carro cadastrado com sucesso!');
    res.redirect('/carros/gerencia');
  } catch (err) {
    req.flash('error_msg', 'Erro ao cadastrar carro.');
    res.redirect('/carros/novo');
  }
});

// GET editar carro
router.get('/:id/editar', autenticado, async (req, res) => {
  try {
    const carro = await Carro.findById(req.params.id);
    if (!carro) {
      req.flash('error_msg', 'Carro não encontrado.');
      return res.redirect('/carros/gerencia');
    }
    res.render('carros/formulario', {
      carro,
      acao: 'Atualizar',
      method: 'POST',
      action: `/carros/${carro._id}?_method=PUT`
    });
  } catch (err) {
    req.flash('error_msg', 'Erro ao carregar carro.');
    res.redirect('/carros/gerencia');
  }
});

// PUT atualizar carro (UPDATE)
router.put('/:id', autenticado, async (req, res) => {
  const { marca, modelo, ano, qtde_disponivel } = req.body;

  try {
    await Carro.findByIdAndUpdate(req.params.id, { marca, modelo, ano, qtde_disponivel });
    req.flash('success_msg', 'Carro atualizado com sucesso!');
    res.redirect('/carros/gerencia');
  } catch (err) {
    req.flash('error_msg', 'Erro ao atualizar carro.');
    res.redirect('/carros/gerencia');
  }
});

// DELETE remover carro (DELETE)
router.delete('/:id', autenticado, async (req, res) => {
  try {
    await Carro.findByIdAndDelete(req.params.id);
    req.flash('success_msg', 'Carro removido com sucesso!');
    res.redirect('/carros/gerencia');
  } catch (err) {
    req.flash('error_msg', 'Erro ao remover carro.');
    res.redirect('/carros/gerencia');
  }
});

// POST vender carro (decrementa quantidade)
router.post('/:id/vender', autenticado, async (req, res) => {
  try {
    const carro = await Carro.findById(req.params.id);
    if (!carro) {
      req.flash('error_msg', 'Carro não encontrado.');
      return res.redirect('/carros/gerencia');
    }

    if (carro.qtde_disponivel <= 0) {
      req.flash('error_msg', 'Carro esgotado, não é possível vender.');
      return res.redirect('/carros/gerencia');
    }

    carro.qtde_disponivel -= 1;
    await carro.save();
    req.flash('success_msg', `Venda de ${carro.marca} ${carro.modelo} registrada!`);
    res.redirect('/carros/gerencia');
  } catch (err) {
    req.flash('error_msg', 'Erro ao registrar venda.');
    res.redirect('/carros/gerencia');
  }
});

module.exports = router;
