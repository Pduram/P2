const express = require('express');
const router = express.Router();
const Usuario = require('../models/Usuario');

// GET cadastro
router.get('/cadastro', (req, res) => {
  res.render('cadastro');
});

// POST cadastro (CREATE)
router.post('/cadastro', async (req, res) => {
  const { nome, login, senha, confirmar_senha } = req.body;

  if (!nome || !login || !senha) {
    req.flash('error_msg', 'Preencha todos os campos.');
    return res.redirect('/cadastro');
  }

  if (senha !== confirmar_senha) {
    req.flash('error_msg', 'As senhas não coincidem.');
    return res.redirect('/cadastro');
  }

  try {
    const existe = await Usuario.findOne({ login });
    if (existe) {
      req.flash('error_msg', 'Login já está em uso.');
      return res.redirect('/cadastro');
    }

    const usuario = new Usuario({ nome, login, senha });
    await usuario.save();
    req.flash('success_msg', 'Cadastro realizado com sucesso! Faça login.');
    res.redirect('/login');
  } catch (err) {
    req.flash('error_msg', 'Erro ao cadastrar usuário.');
    res.redirect('/cadastro');
  }
});

// GET login
router.get('/login', (req, res) => {
  res.render('login');
});

// POST login (READ)
router.post('/login', async (req, res) => {
  const { login, senha } = req.body;

  try {
    const usuario = await Usuario.findOne({ login });
    if (!usuario) {
      req.flash('error_msg', 'Login ou senha incorretos.');
      return res.redirect('/login');
    }

    const ok = await usuario.compararSenha(senha);
    if (!ok) {
      req.flash('error_msg', 'Login ou senha incorretos.');
      return res.redirect('/login');
    }

    req.session.usuario = { id: usuario._id, nome: usuario.nome, login: usuario.login };
    req.flash('success_msg', `Bem-vindo, ${usuario.nome}!`);
    res.redirect('/carros');
  } catch (err) {
    req.flash('error_msg', 'Erro ao fazer login.');
    res.redirect('/login');
  }
});

// GET logout
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

module.exports = router;
